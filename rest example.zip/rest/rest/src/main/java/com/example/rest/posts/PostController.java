package com.example.rest.posts;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.example.rest.user.exceptions.PostNotFoundException;
import com.example.rest.user.exceptions.UserNotFoundException;


@RestController
public class PostController {

	@Autowired
	PostDAOService postDaoService;
	
	@GetMapping("/users/posts")
	public List<Post> retrieveAllPost(){
		return postDaoService.findAll();
	}
	@GetMapping("/users/posts/searchById/{id}")
	public Post retrievePost(@PathVariable int id){
		Post user=postDaoService.findOne(id);
		if(user==null) {
			throw new PostNotFoundException("Post not found, id: "+ id);
		}
		return user;
	}
	
	@GetMapping("/users/posts/searchByName/{name}")
	public List<Post> retrievePostByName(@PathVariable String name){
		List<Post> posts=postDaoService.findPostsByName(name);
		if(posts==null) {
			throw new PostNotFoundException("Posts not found");
		}
		return posts;
	}
	
	@PostMapping("/users/posts")
	public ResponseEntity<Object> addUser(@RequestBody Post post) {
		
		Post savedPost = postDaoService.savePost(post);	
		URI location = ServletUriComponentsBuilder.fromCurrentRequest().path("/{id}").buildAndExpand(savedPost.getId()).toUri();
		return ResponseEntity.created(location).build();
	}
	@DeleteMapping("users/posts/deletePostByUser/{name}")
	public void deletePost(@PathVariable String name) {
		postDaoService.deletePostByUser(name);	
	}
	
 }
