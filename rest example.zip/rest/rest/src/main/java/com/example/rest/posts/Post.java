package com.example.rest.posts;

import java.util.Date;

import com.example.rest.user.User;

public class Post {

	private Integer id;
	
	private String postTitle;
	private String postDiscription;
	private User createdBy;
	private Date createdDate;
	
	public Post(Integer id, String postTitle, String postDiscription, User createdBy, Date createdDate) {
		super();
		this.id = id;
		this.postTitle = postTitle;
		this.postDiscription = postDiscription;
		this.createdBy = createdBy;
		this.createdDate = createdDate;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getPostTitle() {
		return postTitle;
	}

	public void setPostTitle(String postTitle) {
		this.postTitle = postTitle;
	}

	public String getPostDiscription() {
		return postDiscription;
	}

	public void setPostDiscription(String postDiscription) {
		this.postDiscription = postDiscription;
	}

	public User getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(User createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
	
	
	
	
	
	
	
	
}
