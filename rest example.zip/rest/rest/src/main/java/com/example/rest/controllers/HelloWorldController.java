package com.example.rest.controllers;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.example.rest.beans.HelloWorldBean;

@RestController
public class HelloWorldController {

	@GetMapping("/hello-world")
	public String sayHelloWorld() {
		return "Hello Shivkumar";
	}
	
	@GetMapping("/hello-world-bean")
	public HelloWorldBean sayHelloWorldBean() {
		return new HelloWorldBean("Hello Shivkumar");
	}
	
	@GetMapping("/hello-world/with-variable/{name}")
	public HelloWorldBean sayHelloWorldBeanWithVariable(@PathVariable String name) {
		return new HelloWorldBean(String.format("Hello World, %s",name));
	}
	
}
