package com.example.rest.posts;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.springframework.stereotype.Component;

import com.example.rest.user.User;

@Component
public class PostDAOService {
	
	private static List<Post> posts=new ArrayList<>();
	
	static {
		User shiv=new User(1,"Shiv",new Date());
		User prem=new User(1,"Prem",new Date());
		User pradnya=new User(1,"Pradnya",new Date());
		User ragini=new User(1,"Ragini",new Date());
		
		posts.add(new Post(1,"Shiv's Post","This is Shiv's Post Description",shiv,new Date()));
		posts.add(new Post(2,"Prem's Post","This is Prem's Post Description",prem,new Date()));
		posts.add(new Post(3,"Pradnya's Post","This is Pradnya's Post Description",pradnya,new Date()));
		posts.add(new Post(4,"Ragini's Post","This is Ragini's Post Description",ragini,new Date()));
		posts.add(new Post(5,"Shiv's Post 2","This is Another Shiv's Post Description",shiv,new Date()));
		
	}

	public List<Post> findAll(){
		return posts;
	}
	
	public Post savePost(Post post) {
		if(post.getId()==null) {
			post.setId(posts.size()+1);
		}
		posts.add(post);
		return post;
	}
	
	public Post findOne(int id) {
		for(Post post:posts) {
			if(post.getId()==id) {
				return post;
			}
		}
		return null;
	}
	
	public List<Post> findPostsByName(String name) {
		List<Post> userPosts=new ArrayList<>();
		for(Post post:posts) {
			if(post.getCreatedBy().getName().equals(name)) {
				System.out.println("Shiv Post Found");
				userPosts.add(post);
			}
		}
		return userPosts;
	}
	
	public Post deletePostByUser(String name) {
		for (Iterator<Post> iterator = posts.iterator(); iterator.hasNext();) {
		    Post post = iterator.next();
		    if(post.getCreatedBy().getName() .equals(name)) {
		        iterator.remove();
		    }
		   
		}
		return null;
	}
}
